import React, {useEffect, useState} from 'react';
import styles from './Chatbot.css';
import Messages from './components/Messages'
import UserInput from './components/UserInput'
import axios from 'axios';
  
const Chatbot = ({ }) => {
  const [user, setUser] = useState('');
  const [messages, setMessages] = useState([]);

  async function newUser() {
    let message = {message: 'Aguarde um instante...', author: 'bot'};
    setMessages([...messages, message]);

    const options = {
      method: 'POST',
      headers: {'Content-type': 'application/json'},
      url: 'https://a0hrd6nmy2.execute-api.us-east-1.amazonaws.com/testes/history'
    }

    let response = await axios(options);
    if (response.status === 200) {
      setUser(response.data.user);
      setMessages([{message: response.data.lex, author: 'bot'}]);
    }
  }

  useEffect(() => {
    newUser();
  }, [])
  

  return (    
    <div className={styles.chatbot}>
      <div className={styles.chatbotTitle}>
        <h1>Chatbot</h1>
      </div>

      <div className={styles.chatbotMessages} id='botMessagesId'>
        <Messages messages={messages} />
      </div>

      <UserInput messages={messages} setMessages={setMessages} user={user}/>
    </div>
  )
}

Chatbot.schema = {
  title: 'editor.chatbot.title',
  description: 'editor.chatbot.description',
  type: 'object',
  properties: {},
}

export default Chatbot
