import React, { useState } from 'react';
import styles from './UserInput.css';
import axios from 'axios'

const UserInput = ({ messages, setMessages, user }) => {
	const [userMessage, setUserMessage] = useState('');

	async function sendMsg(element) {
		if (userMessage === '') return;
		
		let msg = { message: userMessage, author: 'user' }
		setUserMessage('')
		let updatedMessages = [...messages, msg];
		setMessages(updatedMessages);

		const options = {
			method: 'POST',
			headers: { 'Content-type': 'application/json' },
			url: 'https://a0hrd6nmy2.execute-api.us-east-1.amazonaws.com/testes/send',
			data: {
				user: user,
				message: userMessage
			}
		}

		let response = await axios(options);
		if (response.status === 200) {
			let botMsg = { message: response.data.lex, author: 'bot' }
			setMessages([...updatedMessages, botMsg]);
		}
	}

	return (
		<>
			<div className={styles.inputMessageBox}>
				<input
					onChange={e => setUserMessage(e.target.value)}
					className={styles.messageInput}
					placeholder="Digite sua mensagem aqui"
					onKeyDown={(event) => {
						if (event.key === 'Enter') {
							sendMsg();
						}
					}}
					value={userMessage}
				/>
				<button className={styles.sendMessage} onClick={sendMsg}>Enviar</button>
			</div>
		</>
	)
}

export default UserInput
