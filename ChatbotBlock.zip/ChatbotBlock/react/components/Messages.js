import React from 'react';
import styles from './Messages.css';

const Messages = ({ messages }) => {

  return (
    <>
      {messages.map(message => {
        return <div className={message.author === 'user' ? styles.userMessageBox : styles.botMessageBox}>
          <p className={message.author === 'user' ? styles.userMessage : styles.botMessage}>
            {message.message}
          </p>
        </div>
      })}
    </>
  )
}

export default Messages
